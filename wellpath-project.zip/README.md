# WellPath – wellness coaching app (front-end prototype)

Open `index.html` in a browser. No install needed.

## Logins
- Admin (coach): admin@wellpath.in / admin123
- Client: priya@example.com / priya123

## Files
- `index.html`: page shell
- `css/styles.css`: all styling and colour tokens (top of file)
- `js/app.js`: all screens and logic (home, shop, login, client app, admin panel)
- `js/demo-images.js`: demo pictures; real photos are uploaded in Admin > Products

## Limits of this prototype
Data is saved in the browser only (localStorage), passwords are plain text, and no real
payments, notifications or chat exist. A production version needs a backend
(NestJS + PostgreSQL), Razorpay, push notifications and a mobile app (Expo).

## Put it online
Upload the whole folder to Netlify Drop, GitHub Pages or Vercel.
